#include <stdio.h>
#include <stdlib.h>

#define MAX_ESTUDIANTES 3
#define MAX_LONGITUD_NOMBRE 50
// Definición de la estructura para representar a un estudiante
struct Estudiante{
int numero_registro;
char nombre [MAX_LONGITUD_NOMBRE];
char carrera [MAX_LONGITUD_NOMBRE];
int edad;
};

int main(void) {
  // Crear un arreglo de estructuras Estudiantes
  struct Estudiante estudiantes[MAX_ESTUDIANTES];
  // Ingresar datos de los estudiantes
  printf("Ingresar datos de los estudiantes: \n\n");

  for(int i = 0; i < MAX_ESTUDIANTES; i++){
    //solicitar y guardar los datos
    printf("%d : \n\n",i+1);
    printf("Número de registro: ");
    scanf("%d",&(estudiantes[i].numero_registro));
    printf("\n\nNombre (con espacios entre nombre y apellido): ");
    scanf(" %[^\n]s", estudiantes[i].nombre);
    printf("\n\nCarrera: ");
    scanf(" %[^\n]s", estudiantes[i].carrera);
    printf("\n\nEdad: ");
    scanf("%d", &(estudiantes[i].edad));
    system("clear");
  }
  for(int i = 0; i < MAX_ESTUDIANTES; i++){
    printf("Estudiante %d :", i+1);
    printf("\n\nNúmero de registro: %d", estudiantes[i].numero_registro);
    printf("\n\nNombre: %s", estudiantes[i].nombre);
    printf("\n\nCarrera: %s", estudiantes[i].carrera);
    printf("\n\nEdad: %d \n\n\n", estudiantes[i].edad);
  }
  return 0;
}

/*
#include <stdio.h>
#include <stdlib.h>

#define MAX_ESTUDIANTES 3
#define MAX_LONGITUD_NOMBRE 50
// Definición de la estructura para representar a un estudiante
struct Estudiante{
int numero_registro;
char nombre [MAX_LONGITUD_NOMBRE];
char carrera [MAX_LONGITUD_NOMBRE];
int edad;
};

int main(void) {
  // Crear un arreglo de estructuras Estudiantes
  struct Estudiante estudiantes[MAX_ESTUDIANTES];
  // Crear puntero
  struct Estudiante *PtrEstudiante;
  // Ingresar datos de los estudiantes
  printf("Ingresar datos de los estudiantes: \n\n");

  for(int i = 0; i < MAX_ESTUDIANTES; i++){
    //solicitar y guardar los datos
    printf("%d : \n\n",i+1);
    printf("Número de registro: ");
    scanf("%d",&(estudiantes[i].numero_registro));
    printf("\n\nNombre (con espacios entre nombre y apellido): ");
    scanf(" %[^\n]s", estudiantes[i].nombre);
    printf("\n\nCarrera: ");
    scanf(" %[^\n]s", estudiantes[i].carrera);
    printf("\n\nEdad: ");
    scanf("%d", &(estudiantes[i].edad));
    system("clear");
  }
  for(PtrEstudiante=estudiantes; PtrEstudiante < estudiantes+MAX_ESTUDIANTES; PtrEstudiante++){
    printf("\n\nNúmero de registro: %d", PtrEstudiante->numero_registro);
    printf("\n\nNombre: %s", PtrEstudiante->nombre);
    printf("\n\nCarrera: %s", PtrEstudiante->carrera);
    printf("\n\nEdad: %d \n\n\n", PtrEstudiante->edad);
  }
  return 0;
} */