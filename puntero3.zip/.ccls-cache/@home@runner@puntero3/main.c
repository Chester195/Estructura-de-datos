#include <stdio.h>
//Creamos 2 apuntadores para 2 variables, las sumamos con los apuntadores e imprimimos el resultado//
int main(void) {
  int a = 10;
  int b = 20;
  int resultado = 0;
  int *puntero_a = &a;
  int *puntero_b = &b;
  resultado = *puntero_a + *puntero_b;
  printf("a = %d \n\nb = %d \n\n",a,b);
  printf("resultado = %d\n\n",resultado);
  *puntero_a = 30;
  printf("a = %d \n\nb = %d \n\n",a,b);
  return 0;
}