#include <stdio.h>

int main(void) {
  //Definir variables enteras
  int a = 10;
  int b = 20;

  //Definir punteros a entero y asignarles las direcciones de las variables
  int *puntero_a = &a;
  int *puntero_b = &b;

  printf("Variable a , valor: %d , dirección: %p", *puntero_a, puntero_a);
  printf("\n\nVariable b , valor: %d , dirección: %p", *puntero_b, puntero_b);
  printf("\n\nPuntero a , valor: %d , dirección: %p", *puntero_a, &puntero_a);
  printf("\n\nPuntero b , valor: %d , dirección: %p", *puntero_b, &puntero_b);
  return 0;
}