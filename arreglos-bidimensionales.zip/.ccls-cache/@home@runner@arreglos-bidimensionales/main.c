#include <stdio.h>

int main(void){
  int matriz2[3][3];
  int matriz3[3][3];
  int res[3][3];
  struct matriz2 *ptr1;
  struct matriz3 *ptr2;

  
  printf("Ingrese los datos de la matriz 1: \n");
   for(int i=0;i<3;i++){
     for(int j=0; j<3; j++){
       printf("  Elemento [%d] [%d]:\n", i+1, j+1);
       scanf("%d", &matriz2 [i][j]);
     }
   }
   //Imprimir la matriz
   for(int i=0;i<3;i++){
     for(int j=0; j<3; j++){
       printf("[%d]", matriz2 [i][j]);
     }
     printf("\n");
   }
  printf("Ingrese los datos de la matriz 2: \n");
   for(int i=0;i<3;i++){
     for(int j=0; j<3; j++){
       printf("  Elemento [%d] [%d]:\n", i+1, j+1);
       scanf("%d", &matriz3 [i][j]);
     }
   }
   //Imprimir la matriz
   for(int i=0;i<3;i++){
     for(int j=0; j<3; j++){
       printf("[%d]", matriz3 [i][j]);
     }
     printf("\n");
   }

  for(int i=0;i<3;i++){
    for(int j=0;j<3;j++){
      res[i][j]=matriz2[i][j] + matriz3[i][j];
      printf("%d",  res[i][j]);
    }
    printf("\n");
  }
  return 0;
}
/*int main(void) {
  // Declarando una matriz de 2x2
  int matriz[2][2];
  int matriz2[3][3];
  int matriz3[3][3];
  int res[3][3];

  printf("Ingrese los datos de la matriz 1: \n");
   for(int i=0;i<3;i++){
     for(int j=0; j<3; j++){
       printf("  Elemento [%d] [%d]:\n", i+1, j+1);
       scanf("%d", &matriz2 [i][j]);
     }
   }
   //Imprimir la matriz
   for(int i=0;i<3;i++){
     for(int j=0; j<3; j++){
       printf("[%d]", matriz2 [i][j]);
     }
     printf("\n");
   }
  printf("Ingrese los datos de la matriz 2: \n");
   for(int i=0;i<3;i++){
     for(int j=0; j<3; j++){
       printf("  Elemento [%d] [%d]:\n", i+1, j+1);
       scanf("%d", &matriz3 [i][j]);
     }
   }
   //Imprimir la matriz
   for(int i=0;i<3;i++){
     for(int j=0; j<3; j++){
       printf("[%d]", matriz3 [i][j]);
     }
     printf("\n");
   }

  for(int i=0;i<3;i++){
    for(int j=0;j<3;j++){
      res[i][j]=matriz2[i][j] + matriz3[i][j];
      printf("%d",  res[i][j]);
    }
    printf("\n");
  }
  
 
          return 0;
        }*/
