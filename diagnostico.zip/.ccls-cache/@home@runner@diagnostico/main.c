#include <stdio.h>

struct laboratorio {
  int id;
  char nombre[20];
  int no_equipos;
  char caracteristica_tecnica[20];
};

int main() {

  struct laboratorio lista_laboratorios[10];
int cantidad;
  printf("Cuantos laboratorios quiere registarr?");
    scanf("%d", &cantidad);

  
  // Inicializamos los elementos del arreglo con valores aleatorios
  for (int i = 0; i < cantidad; i++) {
    printf("Cual es el id de tu laboratorio?");
    scanf("%d", &lista_laboratorios[i].id);
    printf("Cual es el nombre de tu laboratorio?");
    scanf("%s", lista_laboratorios[i].nombre);
    printf("Cuantos equipos hay en tu laboratorio?");
    scanf("%d", &lista_laboratorios[i].no_equipos);
    printf("Cual es la caracteristica tecnica de cada equipo?");
    scanf("%s", lista_laboratorios[i].caracteristica_tecnica);

  
  }

  // Imprimimos los elementos del arreglo
 for (int i = 0; i < cantidad; i++) {
    printf("El laboratorio %s, con id: %d,cuenta con %d equipos con la caracteristica de ser: %s \n", lista_laboratorios[i].nombre,lista_laboratorios[i].id,lista_laboratorios[i].no_equipos,lista_laboratorios[i].caracteristica_tecnica);
 }
  return 0;
}