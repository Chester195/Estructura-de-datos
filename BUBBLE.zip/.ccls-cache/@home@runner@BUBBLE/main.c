#include <stdio.h>
#include <stdlib.h>
#include <time.h>

//funcion para llenar el arreglo
/*en esta funcion utilizamos un grupo for para ir llenando el arreglo aleatoriamente con la 
funcion rand*/
/* tomamos en cuenta la variable 'espacios' la cual se lleno despues de preguntarle al usuario cuantos espacios tendria el arreglo, y utilizamos esa cantidad como parametro en el bucle*/
void LlenarArreglo(int arreglo[], int espacios){
 for(int i=0; i < espacios; i++){
    //funcion para generar numeros aleatorios
   arreglo[i]=rand()%100;
 }
}
//funcion para imprimir los numeros dentro del arreglo
/*despues de llenar el arreglo aleatoriamente con la funcion anterior, procedemos a imprimir los datos del arreglo utilizando un bucle for*/
void imprimirarreglo(int arreglo[], int espacios){
  printf("Los numeros de tu arreglo son:\n");
  for(int i=0; i < espacios; i++){
    printf("%d ", arreglo[i]);
  }
}
//funcion para ordenamiento burbuja
/* con el bubblesort, creamos una funcion que permite ordenar una secuencia de numeros de cierta manera, en este caso de menor a mayor, y funciona comparando cada numero con su numero de la derecha, y en caso de ser mayor, cambiar posicion con este, y asi sucesivamente hasta que a la izquierda queden los numeros mas bajos, y a la derecha los numeros mas altos, en orden*/
void bubblesort(int arreglo[], int espacios){
  int temp;
  for(int i=0; i<espacios; i++){
    for(int j=0; j<i; j++){
      if (arreglo[i]<arreglo[j]){
        temp=arreglo[j];
        arreglo[j]=arreglo[i];
        arreglo[i]=temp;
        
      }
    }
   
  }
  
}
int main(void) {
  //creamos la variable 'espacios' ,variable que indica el tamaño del arreglo
  int espacios;
  //preguntamos al usuario cuantos espacios quiere que haya en el arreglo
  printf("Cuantos espacios quieres que haya en el arreglo?\n");
  scanf("%d", &espacios);
   int arreglo[espacios];
  //llamamos a las funciones para llenar el arreglo e imprimirlo
  LlenarArreglo(arreglo, espacios);
  //qutilizamos este bloque de codigo qque mide las iteraciones que hubieron en el codigo y te muestra el tiempo de ejecucion de estas
  int msec = 0, trigger = 10; 
  clock_t before = clock();
  int iterations =0;
  do {
    bubblesort( arreglo, espacios);

    clock_t difference = clock() - before;
    msec = difference * 1000 / CLOCKS_PER_SEC;
    iterations++;
  } while ( msec < trigger );

  //al final presentamos el arreglo ordenado, y el tiempo de ejecucion
  printf("\nTiempo utilizado: %d seegundos, %d millisegundos (%d iteraciones)\n",
    msec/1000, msec%1000,iterations);
  imprimirarreglo(arreglo, espacios);
  
  return 0;
}