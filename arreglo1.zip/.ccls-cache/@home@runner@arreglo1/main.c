#include <stdio.h>

void LlenadoArreglo(int array[], int size){
  for(int i = 0; i < size; i++){
    printf("Elemento #%d:",i + 1);
    scanf("%d", &array[i]);
  }
}

int main(void){
  int arreglo[] = {64, 34, 25, 12, 22, 22, 11, 90};
  int tamano = sizeof(arreglo) / sizeof(arreglo[0]);

  LlenadoArreglo(arreglo, tamano);

  return 0;
}
