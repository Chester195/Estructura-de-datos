#include <stdio.h>

int main(void) {
  //Definir una variable entera
  int numero = 42;
  int *ptrnumero = &numero;
  printf("ptrnumero = %d", ptrnumero);
  printf("\n\n*ptrnumero = %d", *ptrnumero);
  printf("\n\n&ptrnumero = %d", &ptrnumero);
  printf("\n\n*&ptrnumero = %d", *&ptrnumero);
  *ptrnumero = 69;
  printf("\n\nnumero = %d", numero);
  return 0;
}