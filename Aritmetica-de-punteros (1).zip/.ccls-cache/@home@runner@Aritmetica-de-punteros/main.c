#include <stdio.h>
// Declaramos constantes
#define MAX_LONGITUD_NOMBRE 50
#define MAX_ESTUDIANTES 2
// Estructura de un estudiante
typedef struct {
  int numero_registro;
  char nombre[MAX_LONGITUD_NOMBRE];
  char carrera[MAX_LONGITUD_NOMBRE];
  int edad;
} estudiante;

int main(void) {
  // crear un arreglo de estructura de estudiantes
  estudiante arreglo[MAX_ESTUDIANTES];
  // ingresar datos de los estudiantes
  printf("Ingresa los datos del alumno:\n");
    estudiante *ptrEstudiante;


  for (int i = 0; i < MAX_ESTUDIANTES; i++) {
    printf("Estudiante #%d\n", i + 1);
    printf("Numero de registro:\n");
    scanf("%d", &arreglo[i].numero_registro);
    printf("Nombre del estudiante: ");
    scanf(" %[^\n]s", arreglo[i].nombre);
    printf("Nombre de la carrera: \n");
    scanf(" %[^\n]s", arreglo[i].carrera);
    printf("Edad: \n");
    scanf("%d", &arreglo[i].edad);
    printf("\n");
  }
  for (ptrEstudiante=arreglo;ptrEstudiante<arreglo+MAX_ESTUDIANTES; ptrEstudiante++){
    printf("Numero de registro: %d\n", ptrEstudiante->numero_registro);
    printf("Nombre del estudiante: %s \n",  ptrEstudiante->nombre);
    printf("Nombre de la carrera: %s\n ",  ptrEstudiante->carrera);
    printf("Edad: %d \n",  ptrEstudiante->edad);
  }
  return 0;
}