#include <stdio.h>
#include <stdlib.h>
#define MAX_DISPOSITIVOS 5
struct DispositivoRed {
char tipo[20];
int puertos;
char direccionIP[15]; };

int main(void) {
  struct DispositivoRed DispositivoRed[MAX_DISPOSITIVOS];
  struct DispositivoRed *PtrDisp;
  printf("Ingrese los dispositivos de Red");

  for(PtrDisp=DispositivoRed;PtrDisp < DispositivoRed + MAX_DISPOSITIVOS;PtrDisp++){
    printf("\n\nTípo:");
    scanf(" %s", PtrDisp->tipo);
    printf("\n\nPuertos:");
    scanf("%d", &(PtrDisp->puertos));
    printf("\n\nDirección IP:");
    scanf(" %s", PtrDisp->direccionIP);
    system("clear");
  }
  for(PtrDisp=DispositivoRed;PtrDisp < DispositivoRed + MAX_DISPOSITIVOS;PtrDisp++){
    printf("\n\nTípo: %s ", PtrDisp->tipo);
    printf("\n\nPuertos: %d ", PtrDisp->puertos);
    printf("\n\nDirección IP: %s ", PtrDisp->direccionIP);
  }
  return 0;
}