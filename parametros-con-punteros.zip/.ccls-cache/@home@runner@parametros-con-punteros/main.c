//paso de parametros con punteros
#include <stdio.h>
void duplicarElementos(int *arr, int tam){
  for(int i=0;i<tam;i++){
    arr[i]=arr[i]*2;
  }
}
void imprimirArreglo(int *arr,int tam){
  printf("Arreglo resultante:");
  for(int i=0; i<tam; i++){
   printf("%d\n", arr[i]);
  }
}

int main(void) {
  const int tamano=5;
  int miArreglo[]={1,2,3,4,5};
  //llamar a la funcion para duplicar elementos
  duplicarElementos(miArreglo,tamano);
  //llamar a la funcion para imprimir los elementos duplicado del arrelgo
  imprimirArreglo(miArreglo,tamano);
  return 0;
}