#include <stdio.h>
typedef struct {
  char tipo[20];
  int puertos;
  char direccionIP[15];
} estructura;
int main(void) {
  //arreglo de estructuras
  estructura DispositivoRed[5];
  estructura *ptrDispositivos;
// bucle for con aritmetica de punteros para llenar el arreglo
  for (ptrDispositivos = DispositivoRed; ptrDispositivos < DispositivoRed + 5;
       ptrDispositivos++) {
    printf("Tipo de dispositivo: ");
    scanf(" %[^\n]s", DispositivoRed->tipo);
    printf("Numero de puertos: \n");
    scanf("%d", &DispositivoRed->puertos);
    printf("Direccion IP: \n");
    scanf(" %[^\n]s", DispositivoRed->direccionIP);
    printf("\n");
  }
  // bucle for con aritmetica de punteros para imprimir el arreglo
  for (ptrDispositivos = DispositivoRed; ptrDispositivos < DispositivoRed + 5;
       ptrDispositivos++) {
    printf("Tipo de dispositivo: %s", DispositivoRed->tipo);
    printf("Numero de puertos: %d\n", DispositivoRed->puertos);
    printf("Direccion IP: %s\n", DispositivoRed->direccionIP);
    printf("\n");
  }

  return 0;
}