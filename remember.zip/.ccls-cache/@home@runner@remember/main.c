#include <stdio.h>
int main(void){
char nombre[30];
  printf("Cual es tu nombre?");
  scanf("%s",nombre);
  printf("Bienvenido al mundo %s", nombre);
  return 0;
}
