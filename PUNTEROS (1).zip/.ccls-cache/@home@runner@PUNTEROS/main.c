#include <stdio.h>


int main(void) {
  float numeros[18];
  float decimas[18]={.1,0,-.2,.3,.4,.5,-.1,0,.2,.3,.4,0,-.1,0,.2,.1,0,.1};
  float *ptrnumeros=numeros; //El puntero apunta al primer elemento a
  //for para llenar un arreglo con punteros
  for(int i=0; i < 18; i++){
    printf("Escribe la calificacion de el alumno %d :", i+1);
     scanf("%f", &*(ptrnumeros+i)); 
  }
  //for para sumar las calificaciones con las decimas del otro arreglo
  for(int i=0; i<18; i++){
    *(ptrnumeros+i) = *(ptrnumeros+i)+decimas[i];
    printf("Calificaciones sumando las decimas con punteros: %f\n", *(ptrnumeros+i));
  }

 
  return 0;
}